﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dashboard))
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblPremiumPackageCount = New System.Windows.Forms.Label()
        Me.lblBasicPackageCount = New System.Windows.Forms.Label()
        Me.lblStandardPackageCount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.lblIssuesCount = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblCustomerCount = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblTechStaffCount = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblPackagesCount = New System.Windows.Forms.Label()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel7.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel6.Controls.Add(Me.lblPackagesCount)
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Label13)
        Me.Panel6.Controls.Add(Me.Label12)
        Me.Panel6.Controls.Add(Me.lblPremiumPackageCount)
        Me.Panel6.Controls.Add(Me.lblBasicPackageCount)
        Me.Panel6.Controls.Add(Me.lblStandardPackageCount)
        Me.Panel6.Controls.Add(Me.Label5)
        Me.Panel6.Location = New System.Drawing.Point(834, 118)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(296, 451)
        Me.Panel6.TabIndex = 13
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(19, 138)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(102, 37)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Basic"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(19, 333)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(156, 37)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Premium"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(19, 236)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(154, 37)
        Me.Label12.TabIndex = 8
        Me.Label12.Text = "Standard"
        '
        'lblPremiumPackageCount
        '
        Me.lblPremiumPackageCount.AutoSize = True
        Me.lblPremiumPackageCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPremiumPackageCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblPremiumPackageCount.Location = New System.Drawing.Point(207, 333)
        Me.lblPremiumPackageCount.Name = "lblPremiumPackageCount"
        Me.lblPremiumPackageCount.Size = New System.Drawing.Size(52, 51)
        Me.lblPremiumPackageCount.TabIndex = 7
        Me.lblPremiumPackageCount.Text = "2"
        '
        'lblBasicPackageCount
        '
        Me.lblBasicPackageCount.AutoSize = True
        Me.lblBasicPackageCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBasicPackageCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblBasicPackageCount.Location = New System.Drawing.Point(207, 138)
        Me.lblBasicPackageCount.Name = "lblBasicPackageCount"
        Me.lblBasicPackageCount.Size = New System.Drawing.Size(50, 51)
        Me.lblBasicPackageCount.TabIndex = 6
        Me.lblBasicPackageCount.Text = "5"
        '
        'lblStandardPackageCount
        '
        Me.lblStandardPackageCount.AutoSize = True
        Me.lblStandardPackageCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStandardPackageCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblStandardPackageCount.Location = New System.Drawing.Point(207, 236)
        Me.lblStandardPackageCount.Name = "lblStandardPackageCount"
        Me.lblStandardPackageCount.Size = New System.Drawing.Size(52, 51)
        Me.lblStandardPackageCount.TabIndex = 5
        Me.lblStandardPackageCount.Text = "3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(30, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(172, 37)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Package`s"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel5.Controls.Add(Me.lblIssuesCount)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Location = New System.Drawing.Point(366, 437)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(417, 132)
        Me.Panel5.TabIndex = 12
        '
        'lblIssuesCount
        '
        Me.lblIssuesCount.AutoSize = True
        Me.lblIssuesCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIssuesCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblIssuesCount.Location = New System.Drawing.Point(253, 38)
        Me.lblIssuesCount.Name = "lblIssuesCount"
        Me.lblIssuesCount.Size = New System.Drawing.Size(52, 51)
        Me.lblIssuesCount.TabIndex = 6
        Me.lblIssuesCount.Text = "2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(33, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 37)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Issues"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel4.Controls.Add(Me.lblCustomerCount)
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Location = New System.Drawing.Point(366, 118)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(417, 135)
        Me.Panel4.TabIndex = 11
        '
        'lblCustomerCount
        '
        Me.lblCustomerCount.AutoSize = True
        Me.lblCustomerCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblCustomerCount.Location = New System.Drawing.Point(253, 45)
        Me.lblCustomerCount.Name = "lblCustomerCount"
        Me.lblCustomerCount.Size = New System.Drawing.Size(75, 51)
        Me.lblCustomerCount.TabIndex = 4
        Me.lblCustomerCount.Text = "10"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(33, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(191, 37)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Customer`s"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel3.Controls.Add(Me.lblTechStaffCount)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Location = New System.Drawing.Point(366, 274)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(417, 139)
        Me.Panel3.TabIndex = 10
        '
        'lblTechStaffCount
        '
        Me.lblTechStaffCount.AutoSize = True
        Me.lblTechStaffCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTechStaffCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTechStaffCount.Location = New System.Drawing.Point(253, 25)
        Me.lblTechStaffCount.Name = "lblTechStaffCount"
        Me.lblTechStaffCount.Size = New System.Drawing.Size(51, 51)
        Me.lblTechStaffCount.TabIndex = 5
        Me.lblTechStaffCount.Text = "4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Elephant", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(33, 39)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(179, 37)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Tech Staff "
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gray
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1178, 100)
        Me.Panel1.TabIndex = 15
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Gray
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1178, 100)
        Me.Panel2.TabIndex = 4
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Impact", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(443, 32)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(340, 48)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "ADMIN DASHBOARD"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Impact", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(268, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(340, 48)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ADMIN DASHBOARD"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Purple
        Me.Panel7.Controls.Add(Me.PictureBox1)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel7.Location = New System.Drawing.Point(0, 100)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(281, 501)
        Me.Panel7.TabIndex = 16
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(32, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(218, 232)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblPackagesCount
        '
        Me.lblPackagesCount.AutoSize = True
        Me.lblPackagesCount.Font = New System.Drawing.Font("Elephant", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPackagesCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblPackagesCount.Location = New System.Drawing.Point(208, 34)
        Me.lblPackagesCount.Name = "lblPackagesCount"
        Me.lblPackagesCount.Size = New System.Drawing.Size(75, 51)
        Me.lblPackagesCount.TabIndex = 5
        Me.lblPackagesCount.Text = "10"
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1178, 601)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dashboard"
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblPremiumPackageCount As System.Windows.Forms.Label
    Friend WithEvents lblBasicPackageCount As System.Windows.Forms.Label
    Friend WithEvents lblStandardPackageCount As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents lblIssuesCount As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents lblCustomerCount As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblTechStaffCount As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblPackagesCount As System.Windows.Forms.Label
End Class
