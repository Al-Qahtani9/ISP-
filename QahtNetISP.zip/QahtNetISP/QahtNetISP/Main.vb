﻿Public Class Main

    Private Sub btnCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustomer.Click
        Dim customerForm As New Customer()
        customerForm.Show() ' Use .Show() to open it modelessly, or .ShowDialog() for modal 
    End Sub

    Private Sub btnTechStaff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTechStaff.Click
        Dim techStaffForm As New TechStaffForm()
        techStaffForm.Show()
    End Sub

    Private Sub btnPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPayment.Click
        Dim paymentForm As New Payment()
        paymentForm.Show()
    End Sub

    Private Sub btnIssues_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIssues.Click
        Dim issuesForm As New Issues()
        issuesForm.Show()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click

        Me.Hide()

        Dim loginForm As New LoginForm
        loginForm.Show()

        AddHandler loginForm.FormClosed, AddressOf LoginForm_FormClosed
    End Sub

    Private Sub LoginForm_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        ' Exit the application when the login form is closed  
        Application.Exit()
    End Sub

    Private Sub btnDashboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDashboard.Click
        Dim dashboardForm As New Dashboard()
        dashboardForm.ShowDialog()

    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class