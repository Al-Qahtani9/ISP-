﻿Imports System.Data.SqlClient

Public Class LoginForm

    Private connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\User\OneDrive\Desktop\PROJECT\QahtNetISP\[QahtNetISP].mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"

    Private Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' For demonstration purpose
        If username = "admin" AndAlso password = "password" Then
            Dim mainForm As New Main()
            mainForm.Show()
            Me.Hide()
        Else
            MessageBox.Show("Username and password are incorrect", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub LoginForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class