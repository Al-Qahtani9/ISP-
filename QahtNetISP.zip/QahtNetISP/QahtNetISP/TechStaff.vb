﻿Imports System.Data.SqlClient

Public Class TechStaffForm

    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\User\OneDrive\Desktop\PROJECT\QahtNetISP\[QahtNetISP].mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"
    Dim connection As SqlConnection = New SqlConnection(connectionString)

    Private Property customerData As Object

   

    Private Sub btnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNew.Click
        Dim techid As String = txtTechId.Text
        Dim name As String = txtName.Text
        Dim number As String = txtNumber.Text
        Dim rank As String = cmbRank.SelectedItem.ToString()


        Dim insertQuery As String = "INSERT INTO TechStaff (TechId, Name, Number, Rank) VALUES (@TechId, @Name, @Number, @Rank)"

        ' Create the SQL Command
        Dim cmd As SqlCommand = New SqlCommand(insertQuery, connection)

        cmd.Parameters.AddWithValue("@TechId", techid)
        cmd.Parameters.AddWithValue("@Name", name)
        cmd.Parameters.AddWithValue("@Number", number)
        cmd.Parameters.AddWithValue("@Rank", rank)

        Try
            ' Open the connection
            connection.Open()

            ' Execute the insert query
            cmd.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("New TechStaff added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            
        Catch ex As Exception
            ' Show error message in case of failure
            MessageBox.Show("Error: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub

    Private Sub TechStaffForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
    ' Clear text boxes  
    txtTechId.Text = String.Empty
    txtName.Text = String.Empty
    txtNumber.Text = String.Empty

    ' Reset the combo box  
    cmbRank.SelectedIndex = -1  ' Deselects any selected item  
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim query As String = "DELETE FROM Customers WHERE TechId = @TechId"
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Techid", txtTechId.Text)

                Try
                    connection.Open()
                    command.ExecuteNonQuery()
                    MessageBox.Show("Staff deleted successfully!")
                    If currentIndex() >= TechStaffForm.Rows.Count Then

                        currentIndex() = TechStaffForm.Rows.Count(-1)
                    End If
                    DisplayCurrentstaff()
                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message)
                Finally
                    connection.Close()
                End Try
            End Using
        End Using
    End Sub

    Private Function currentIndex() As Object
        Throw New NotImplementedException
    End Function

    Private Shared Function Rows() As Object
        Throw New NotImplementedException
    End Function

    Private Sub DisplayCurrentstaff()
        Throw New NotImplementedException
    End Sub

End Class