﻿Imports System.Data.SqlClient
Public Class Dashboard
    Private connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\User\OneDrive\Desktop\PROJECT\QahtNetISP\[QahtNetISP].mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"

    Private Sub DashboardForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        UpdateDashboardCounts()
    End Sub

    Private Sub UpdateDashboardCounts()
        Using connection As New SqlConnection(connectionString)
            connection.Open()

           ' Get the customer count  
            Dim customerQuery As String = "SELECT COUNT(*) FROM Customers"
            Dim customerCommand As New SqlCommand(customerQuery, connection)
            Dim customerCount As Integer = CInt(customerCommand.ExecuteScalar())

            ' Get the tech staff count  
            Dim techStaffQuery As String = "SELECT COUNT(*) FROM TechStaff"
            Dim techStaffCommand As New SqlCommand(techStaffQuery, connection)
            Dim techStaffCount As Integer = CInt(techStaffCommand.ExecuteScalar())

            ' Get the issues count  
            Dim issuesQuery As String = "SELECT COUNT(*) FROM Issues"
            Dim issuesCommand As New SqlCommand(issuesQuery, connection)
            Dim issuesCount As Integer = CInt(issuesCommand.ExecuteScalar())

            ' Get the packages count  
            Dim packagesQuery As String = "SELECT COUNT(*) FROM Packages"
            Dim packagesCommand As New SqlCommand(packagesQuery, connection)
            Dim packagesCount As Integer = CInt(packagesCommand.ExecuteScalar())

            ' Update the dashboard labels  
            lblCustomerCount.Text = customerCount.ToString()
            lblTechStaffCount.Text = techStaffCount.ToString()
            lblIssuesCount.Text = issuesCount.ToString()
            lblPackagesCount.Text = packagesCount.ToString()
        End Using
    End Sub
End Class
    