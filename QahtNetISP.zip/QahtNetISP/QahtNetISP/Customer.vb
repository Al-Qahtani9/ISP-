﻿Imports System.Data.SqlClient
Public Class Customer

    Private Property currentIndex As Integer

    Private connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\User\OneDrive\Desktop\PROJECT\QahtNetISP\[QahtNetISP].mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"

    Private Sub btnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNew.Click

        Dim query As String = "INSERT INTO Customers (CustomerId, Name, Address, Package, City, Date) VALUES (@CustomerId, @Name, @Address, @Package, @City, @Date)"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                ' Add parameters  
                command.Parameters.AddWithValue("@CustomerId", txtCustomerId.Text)
                command.Parameters.AddWithValue("@Name", txtName.Text)
                command.Parameters.AddWithValue("@Address", txtAddress.Text)
                command.Parameters.AddWithValue("@Package", cmbPackages.SelectedItem.ToString())
                command.Parameters.AddWithValue("@City", txtCity.Text)
                command.Parameters.AddWithValue("@Date", dtpDate.Value)

                Try
                    connection.Open()
                    command.ExecuteNonQuery()
                    MessageBox.Show("Customer added successfully!")
                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message)
                Finally
                    connection.Close()
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        If currentIndex > 0 Then
            currentIndex -= 1
            DisplayCurrentCustomer()
        Else
            MessageBox.Show("This is the first customer.")
        End If
    End Sub

    Private Sub DisplayCurrentCustomer()
        Throw New NotImplementedException
    End Sub

    Private Shared Function Rows() As Object
        Throw New NotImplementedException
    End Function

    Private Function Customer() As Boolean
        Throw New NotImplementedException
    End Function

    Private Function customerData() As Object
        Throw New NotImplementedException
    End Function

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim query As String = "DELETE FROM Customers WHERE CustomerId = @CustomerId"
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@CustomerId", txtCustomerId.Text)

                Try
                    connection.Open()
                    command.ExecuteNonQuery()
                    MessageBox.Show("Customer deleted successfully!")
                    LoadCustomers()  ' Reload customers to refresh the list  
                    If currentIndex >= customerData.Rows.Count Then
                        currentIndex = customerData.Rows.Count - 1
                    End If
                    DisplayCurrentCustomer()
                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message)
                Finally
                    connection.Close()
                End Try
            End Using
        End Using
    End Sub

    Private Sub LoadCustomers()
        Throw New NotImplementedException
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ClearFormFields()
    End Sub

    Private Sub ClearFormFields()
        ' Clear text boxes  
        txtCustomerId.Text = String.Empty
        txtName.Text = String.Empty
        txtAddress.Text = String.Empty
        txtCity.Text = String.Empty

        cmbPackages.SelectedIndex = -1  ' Deselects any selected item  

        dtpDate.Value = Now
    End Sub

    Private Sub Customer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class